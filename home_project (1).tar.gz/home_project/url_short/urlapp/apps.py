from django.apps import AppConfig


class UrlappConfig(AppConfig):
    name = 'urlapp'
