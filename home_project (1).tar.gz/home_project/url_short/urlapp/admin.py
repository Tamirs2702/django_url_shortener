from django.contrib import admin
from .models import LinkInfo
# Register your models here.
admin.site.register(LinkInfo)